package com.bharath;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Camera {
    private int id;
    private String brand;
    private String model;
    private double perDayPrice;
    private boolean available;

    public Camera(int id, String brand, String model, double perDayPrice, boolean available) {
        this.id = id;
        this.brand = brand;
        this.model = model;
        this.perDayPrice = perDayPrice;
        this.available = available;
    }

    public int getId() {
        return id;
    }

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public double getPerDayPrice() {
        return perDayPrice;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }
}

public class CameraRentalApp {
    private static List<Camera> cameraList = new ArrayList<>();
    private static double walletAmount = 500.0;

    public static void main(String[] args) {
        addPredefinedCameras();

        Scanner scanner = new Scanner(System.in);

        System.out.println("WELCOME TO CAMERA RENTAL APP");
        System.out.println("PLEASE LOGIN TO CONTINUE");

        System.out.print("USERNAME: ");
        String username = scanner.nextLine();

        System.out.print("PASSWORD: ");
        String password = scanner.nextLine();

        if (login(username, password)) {
            System.out.println("LOGIN SUCCESSFUL!");

            boolean exit = false;

            while (!exit) {
                System.out.println("\nOPTIONS:");
                System.out.println("1. MY CAMERA");
                System.out.println("2. RENT A CAMERA");
                System.out.println("3. VIEW ALL CAMERAS");
                System.out.println("4. MY WALLET");
                System.out.println("5. EXIT");

                System.out.print("ENTER YOUR CHOICE: ");
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character

                switch (choice) {
                    case 1:
                        myCameraMenu(scanner);
                        break;
                    case 2:
                        rentCamera(scanner);
                        break;
                    case 3:
                        viewAllCameras();
                        break;
                    case 4:
                        myWalletMenu(scanner);
                        break;
                    case 5:
                        exit = true;
                        break;
                    default:
                        System.out.println("INVALID CHOICE! PLEASE TRY AGAIN.");
                        break;
                }
            }
        } else {
            System.out.println("LOGIN FAILED! INVALID USERNAME OR PASSWORD.");
        }

        scanner.close();
    }

    private static boolean login(String username, String password) {
        // Add your login logic here
        return username.equals("admin") && password.equals("admin123");
    }

    private static void addPredefinedCameras() {
        // Add some predefined cameras
        Camera camera1 = new Camera(1, "Samsung", "DS123", 500.0, true);
        Camera camera2 = new Camera(2, "Sony", "HD214", 500.0, true);
        Camera camera3 = new Camera(3, "Panasonic", "XC", 500.0, true);
        Camera camera4 = new Camera(4, "Canon", "XLR", 500.0, true);
        Camera camera5 = new Camera(5, "Fujitsu", "J5", 500.0, true);
        Camera camera6 = new Camera(6, "Nikon", "D750", 600.0, true);
        Camera camera7 = new Camera(7, "Sony", "A7S II", 700.0, true);
        Camera camera8 = new Camera(8, "Canon", "5D Mark IV", 800.0, true);
        Camera camera9 = new Camera(9, "Panasonic", "GH5", 900.0, true);
        Camera camera10 = new Camera(10, "Canon", "XPL", 400.0, true);
        Camera camera11 = new Camera(11, "Chroma", "CT", 500.0, true);
        Camera camera12 = new Camera(12, "Canon", "Digital", 123.0, true);
        Camera camera13 = new Camera(13, "Sony", "DSLR12", 200.0, true);
        Camera camera14 = new Camera(14, "Canon", "5050", 25000.0, true);
        Camera camera15 = new Camera(15, "Nikon", "2030", 500.0, true);

        cameraList.add(camera1);
        cameraList.add(camera2);
        cameraList.add(camera3);
        cameraList.add(camera4);
        cameraList.add(camera5);
        cameraList.add(camera6);
        cameraList.add(camera7);
        cameraList.add(camera8);
        cameraList.add(camera9);
        cameraList.add(camera10);
        cameraList.add(camera11);
        cameraList.add(camera12);
        cameraList.add(camera13);
        cameraList.add(camera14);
        cameraList.add(camera15);
    }

    private static void myCameraMenu(Scanner scanner) {
        System.out.println("\nMY CAMERA MENU:");
        System.out.println("1. ADD");
        System.out.println("2. REMOVE");
        System.out.println("3. VIEW MY CAMERAS");
        System.out.println("4. GO TO PREVIOUS MENU");

        System.out.print("ENTER YOUR CHOICE: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        switch (choice) {
            case 1:
                addCamera(scanner);
                break;
            case 2:
                removeCamera(scanner);
                break;
            case 3:
                viewMyCameras();
                break;
            case 4:
                break;
            default:
                System.out.println("INVALID CHOICE! PLEASE TRY AGAIN.");
                break;
        }
    }

    private static void addCamera(Scanner scanner) {
        System.out.println("\nADD CAMERA:");

        System.out.print("ENTER THE CAMERA BRAND: ");
        String brand = scanner.nextLine();

        System.out.print("ENTER THE MODEL: ");
        String model = scanner.nextLine();

        System.out.print("ENTER THE PER DAY PRICE (INR): ");
        double perDayPrice = scanner.nextDouble();
        scanner.nextLine(); // Consume the newline character

        int newId = cameraList.size() + 1;
        Camera newCamera = new Camera(newId, brand, model, perDayPrice, true);
        cameraList.add(newCamera);

        System.out.println("YOUR CAMERA HAS BEEN SUCCESSFULLY ADDED TO THE LIST.");
    }

    private static void removeCamera(Scanner scanner) {
        System.out.println("\nREMOVE CAMERA:");

        System.out.println("MY CAMERAS:");
        System.out.printf("%-10s %-15s %-15s %-10s %s\n",
                "CAMERA ID", "BRAND", "MODEL", "PRICE (PER DAY)", "STATUS");

        for (Camera camera : cameraList) {
            System.out.printf("%-10d %-15s %-15s %-10.2f %s\n",
                    camera.getId(), camera.getBrand(), camera.getModel(),
                    camera.getPerDayPrice(), camera.isAvailable() ? "Available" : "Rented");
        }

        System.out.print("ENTER THE CAMERA ID TO REMOVE: ");
        int cameraId = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        boolean removed = false;
        for (Camera camera : cameraList) {
            if (camera.getId() == cameraId) {
                cameraList.remove(camera);
                removed = true;
                break;
            }
        }

        if (removed) {
            System.out.println("CAMERA SUCCESSFULLY REMOVED FROM THE LIST.");
        } else {
            System.out.println("INVALID CAMERA ID! REMOVAL FAILED.");
        }
    }

    private static void viewMyCameras() {
        System.out.println("\nALL CAMERAS:");
        System.out.printf("%-10s %-15s %-15s %-10s %s\n",
                "CAMERA ID", "BRAND", "MODEL", "PRICE (PER DAY)", "STATUS");

        for (Camera camera : cameraList) {
            System.out.printf("%-10d %-15s %-15s %-10.2f %s\n",
                    camera.getId(), camera.getBrand(), camera.getModel(),
                    camera.getPerDayPrice(), camera.isAvailable() ? "Available" : "Rented");
        }
    }

    private static void rentCamera(Scanner scanner) {
        System.out.println("\nRENT A CAMERA:");

        System.out.println("FOLLOWING IS THE LIST OF AVAILABLE CAMERA(S):");
        viewAllCameras();

        System.out.print("ENTER THE CAMERA ID YOU WANT TO RENT: ");
        int cameraId = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        Camera rentedCamera = null;
        for (Camera camera : cameraList) {
            if (camera.getId() == cameraId) {
                rentedCamera = camera;
                break;
            }
        }

        if (rentedCamera != null) {
            if (walletAmount >= rentedCamera.getPerDayPrice()) {
                rentedCamera.setAvailable(false);
                walletAmount -= rentedCamera.getPerDayPrice();
                System.out.printf("YOUR TRANSACTION FOR CAMERA - %s %s with rent INR %.2f HAS SUCCESSFULLY COMPLETED.\n",
                        rentedCamera.getBrand(), rentedCamera.getModel(), rentedCamera.getPerDayPrice());
            } else {
                System.out.println("ERROR: TRANSACTION FAILED DUE TO INSUFFICIENT WALLET BALANCE.");
            }
        } else {
            System.out.println("INVALID CAMERA ID! TRANSACTION FAILED.");
        }
    }

    private static void viewAllCameras() {
        System.out.println("\nALL CAMERAS:");
        System.out.printf("%-10s %-15s %-15s %-10s %s\n",
                "CAMERA ID", "BRAND", "MODEL", "PRICE (PER DAY)", "STATUS");

        for (Camera camera : cameraList) {
            System.out.printf("%-10d %-15s %-15s %-10.2f %s\n",
                    camera.getId(), camera.getBrand(), camera.getModel(),
                    camera.getPerDayPrice(), camera.isAvailable() ? "Available" : "Rented");
        }
    }

    private static void myWalletMenu(Scanner scanner) {
        System.out.println("\nMY WALLET MENU:");
        System.out.println("1. VIEW WALLET BALANCE");
        System.out.println("2. ADD MONEY TO WALLET");
        System.out.println("3. GO TO PREVIOUS MENU");

        System.out.print("ENTER YOUR CHOICE: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        switch (choice) {
            case 1:
                viewWalletBalance();
                break;
            case 2:
                addMoneyToWallet(scanner);
                break;
            case 3:
                break;
            default:
                System.out.println("INVALID CHOICE! PLEASE TRY AGAIN.");
                break;
        }
    }

    private static void viewWalletBalance() {
        System.out.println("\nWALLET BALANCE (INR): " + walletAmount);
    }

    private static void addMoneyToWallet(Scanner scanner) {
        System.out.println("\nADD MONEY TO WALLET:");

        System.out.print("ENTER THE AMOUNT TO ADD (INR): ");
        double amount = scanner.nextDouble();
        scanner.nextLine(); // Consume the newline character

        walletAmount += amount;

        System.out.println("MONEY ADDED SUCCESSFULLY. WALLET BALANCE (INR): " + walletAmount);
    }
}
