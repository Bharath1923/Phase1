/**
 * 
 */
/**
 * @author Bharath
 *
 */
module CameraRental {
}