package com;
import java.util.Arrays;

public class RightRotateArray {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int steps = 5;

        System.out.println("Original Array: " + Arrays.toString(array));

        rightRotateArray(array, steps);

        System.out.println("Right Rotated Array: " + Arrays.toString(array));
    }

    public static void rightRotateArray(int[] array, int steps) {
        int length = array.length;
        int[] temp = new int[length];

        // Copy the original array to a temporary array
        System.arraycopy(array, 0, temp, 0, length);

        // Perform the right rotation
        for (int i = 0; i < length; i++) {
            array[(i + steps) % length] = temp[i];
        }
    }
}
