package com;

import java.util.Arrays;

public class SumInRange {
    public static void main(String[] args) {
        int[] numbers = {2, 5, 3, 8, 6, 1, 9, 4, 7};
        int n = numbers.length;
        int L = 2;
        int R = 6;

        int sum = findSumInRange(numbers, n, L, R);

        System.out.println("Original Array: " + Arrays.toString(numbers));
        System.out.println("Sum of elements in the range [" + L + ", " + R + "]: " + sum);
    }

    public static int findSumInRange(int[] numbers, int n, int L, int R) {
        if (L < 0 || R >= n || L > R) {
            System.out.println("Invalid range");
            return 0;
        }

        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += numbers[i];
        }
        return sum;
    }
}
