package com;

import java.util.Arrays;

public class FourthSmallestElement {
    public static void main(String[] args) {
        int[] list = {10, 5, 7, 2, 9, 1, 8, 3, 6, 4};

        int fourthSmallest = findFourthSmallest(list);

        System.out.println("Original List: " + Arrays.toString(list));
        System.out.println("Fourth Smallest Element: " + fourthSmallest);
    }

    public static int findFourthSmallest(int[] list) {
        if (list.length < 4) {
            System.out.println("List size is less than 4");
            return Integer.MIN_VALUE;
        }

        Arrays.sort(list); // Sort the list in ascending order

        return list[3]; // Return the fourth smallest element (index 3)
    }
}
