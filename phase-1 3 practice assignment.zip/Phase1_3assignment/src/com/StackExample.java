package com;

import java.util.Stack;

public class StackExample {
    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();

        // Inserting elements into the stack
        stack.push(5);
        stack.push(10);
        stack.push(15);

        System.out.println("Stack after inserting elements: " + stack);

        // Removing elements from the stack
        int removedElement = stack.pop();
        System.out.println("Removed element from the stack: " + removedElement);
        System.out.println("Stack after removing an element: " + stack);

        // Peek at the top element of the stack
        int topElement = stack.peek();
        System.out.println("Top element of the stack: " + topElement);

        // Checking if the stack is empty
        boolean isEmpty = stack.empty();
        System.out.println("Is the stack empty? " + isEmpty);
    }
}
