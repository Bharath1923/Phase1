package bharath;
public class OuterClass {
    private int outerInt = 10;

    public void outerMethod() {
        System.out.println("Inside outerMethod");

        // creating an object of the InnerClass
        InnerClass inner = new InnerClass();

        // accessing the inner class method
        inner.innerMethod();
    }

    // Inner class
    public class InnerClass {
        public void innerMethod() {
            System.out.println("Inside innerMethod");
            System.out.println("Value of outerInt: " + outerInt);
        }
    }

    public static void main(String[] args) {
        OuterClass outer = new OuterClass();
        outer.outerMethod();
    }
}
