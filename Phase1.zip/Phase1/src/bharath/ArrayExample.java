package bharath;

public class ArrayExample {

	    public static void main(String[] args) {
	        // declare and initialize an array of strings
	        String[] fruits = {"apple", "banana", "orange"};

	        // print the length of the array
	        System.out.println("Length of the array: " + fruits.length);

	        // print the elements of the array using a for-each loop
	        System.out.print("Array elements: ");
	        for (String fruit : fruits) {
	            System.out.print(fruit + " ");
	        }
	        System.out.println();

	        // modify the second element of the array
	        fruits[1] = "grape";

	        // print the modified elements of the array using a for loop
	        System.out.print("Modified array elements: ");
	        for (int i = 0; i < fruits.length; i++) {
	            System.out.print(fruits[i] + " ");
	        }
	        System.out.println();
	    }
	}

