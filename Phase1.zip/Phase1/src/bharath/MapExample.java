package bharath;

import java.util.HashMap;
import java.util.Map;

public class MapExample {
    public static void main(String[] args) {
        // create a map
        Map<String, Integer> map = new HashMap<>();
        map.put("apple", 1);
        map.put("banana", 2);
        map.put("orange", 3);
        map.put("grape", 4);
        // print the map
        System.out.println("Map: " + map);
        // access an element of the map
        System.out.println("Value for key 'banana': " + map.get("banana"));
        // remove an element from the map
        map.remove("orange");
        System.out.println("Map after removing 'orange': " + map);
        // check if a key or value is in the map
        System.out.println("Contains key 'banana': " + map.containsKey("banana"));
        System.out.println("Contains value 4: " + map.containsValue(4));
        // iterate over the map
        System.out.println("Iterating over the map:");
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println(entry.getKey() + " => " + entry.getValue());
        }
    }
}
