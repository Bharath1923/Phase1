package bharath;

public class ConstructorExample {
    private String name;
    private int age;

    // default constructor
    public ConstructorExample() {
        name = "John Doe";
        age = 30;
    }

    // parameterized constructor
    public ConstructorExample(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // copy constructor
    public ConstructorExample(ConstructorExample other) {
        this.name = other.name;
        this.age = other.age;
    }

    public void display() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }

    public static void main(String[] args) {
        ConstructorExample obj1 = new ConstructorExample(); // calling default constructor
        ConstructorExample obj2 = new ConstructorExample("Jane Smith", 25); // calling parameterized constructor
        ConstructorExample obj3 = new ConstructorExample(obj2); // calling copy constructor
        
        System.out.println("Object 1:");
        obj1.display();
        
        System.out.println("Object 2:");
        obj2.display();
        
        System.out.println("Object 3:");
        obj3.display();
    }
}
