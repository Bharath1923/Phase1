package bharath;

public class StringConversionExample {
    public static void main(String[] args) {
        // create a string
        String str = "Hello, World!";

        // convert the string to a StringBuffer
        StringBuffer stringBuffer = new StringBuffer(str);

        // convert the string to a StringBuilder
        StringBuilder stringBuilder = new StringBuilder(str);

        // print the original string and the converted objects
        System.out.println("Original string: " + str);
        System.out.println("StringBuffer: " + stringBuffer);
        System.out.println("StringBuilder: " + stringBuilder);
    }
}
