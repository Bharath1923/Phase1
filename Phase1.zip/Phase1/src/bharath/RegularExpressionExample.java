package bharath;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpressionExample {
    public static void main(String[] args) {
        // create a regular expression pattern to match email addresses
        Pattern pattern = Pattern.compile("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}");

        // create a sample text to search for email addresses
        String text = "My email is bharath@example.com. You can also reach me at bharath.doe@example.com.";

        // create a matcher to find all email addresses in the text
        Matcher matcher = pattern.matcher(text);

        // print all the email addresses found in the text
        while (matcher.find()) {
            System.out.println("Found email: " + matcher.group());
        }
    }
}
