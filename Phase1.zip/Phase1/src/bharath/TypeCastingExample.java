package bharath;

public class TypeCastingExample {
    public static void main(String[] args) {
        // implicit type casting
        int i = 10;
        long l = i;
        float f = l;
        double d = f;
        System.out.println("Implicit Type Casting:");
        System.out.println("int to long: " + l);
        System.out.println("long to float: " + f);
        System.out.println("float to double: " + d);
        
        // explicit type casting
        double d1 = 123.45;
        float f1 = (float) d1;
        long l1 = (long) f1;
        int i1 = (int) l1;
        System.out.println("Explicit Type Casting:");
        System.out.println("double to float: " + f1);
        System.out.println("float to long: " + l1);
        System.out.println("long to int: " + i1);
    }
}
