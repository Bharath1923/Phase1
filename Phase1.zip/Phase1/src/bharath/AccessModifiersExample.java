package bharath;

public class AccessModifiersExample {
    public static void main(String[] args) {
        Car car = new Car("Toyota", "Camry", 2021);
        car.displayCarDetails(); // output: "Make: Toyota, Model: Camry, Year: 2021"
        car.setMake("Honda"); // can access public method to set make
        car.setModel("Civic"); // can access protected method to set model
        // car.setYear(2022); // cannot access private method to set year
        car.displayCarDetails(); // output: "Make: Honda, Model: Civic, Year: 2021"
    }
}

class Car {
    public String make;
    protected String model;
    private int year;

    public Car(String make, String model, int year) {
        this.make = make;
        this.model = model;
        this.year = year;
    }

    public void setMake(String make) {
        this.make = make;
    }

    protected void setModel(String model) {
        this.model = model;
    }

    private void setYear(int year) {
        this.year = year;
    }

    public void displayCarDetails() {
        System.out.println("Make: " + this.make + ", Model: " + this.model + ", Year: " + this.year);
    }
}
