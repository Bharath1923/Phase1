package bharath;

import java.util.*;

public class Collections {
    public static void main(String[] args) {
        // create a list
        List<String> list = new ArrayList<>();

        // add elements to the list
        list.add("apple");
        list.add("banana");
        list.add("orange");
        list.add("grape");

        // print the list
        System.out.println("List: " + list);

        // access elements of the list
        System.out.println("First element: " + list.get(0));
        System.out.println("Second element: " + list.get(1));

        // change an element of the list
        list.set(1, "kiwi");
        System.out.println("Changed list: " + list);

        // remove an element from the list
        list.remove(2);
        System.out.println("List after removing an element: " + list);

        // create a set
        Set<Integer> set = new HashSet<>();

        // add elements to the set
        set.add(1);
        set.add(2);
        set.add(3);
        set.add(4);
        set.add(5);

        // print the set
        System.out.println("Set: " + set);

        // check if an element is in the set
        System.out.println("Is 3 in the set? " + set.contains(3));
        System.out.println("Is 6 in the set? " + set.contains(6));

        // remove an element from the set
        set.remove(4);
        System.out.println("Set after removing an element: " + set);

        // create a map
        Map<String, Integer> map = new HashMap<>();

        // add elements to the map
        map.put("John", 25);
        map.put("Jane", 30);
        map.put("Bob", 35);
        map.put("Mary", 40);

        // print the map
        System.out.println("Map: " + map);

        // access an element of the map
        System.out.println("John's age: " + map.get("John"));

        // remove an element from the map
        map.remove("Bob");
        System.out.println("Map after removing an element: " + map);
    }
}
