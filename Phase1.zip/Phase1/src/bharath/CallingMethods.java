package bharath;

public class CallingMethods {
    public static void main(String[] args) {
        CallingMethods obj = new CallingMethods();
        
        // call a method with no parameters and no return value
        obj.sayHello();
        
        // call a method with parameters and no return value
        obj.sayHelloTo("John");
        
        // call a method with parameters and a return value
        int sum = obj.calculateSum(3, 5);
        System.out.println("Sum = " + sum);
        
        // call a static method without creating an object
        int product = multiply(4, 6);
        System.out.println("Product = " + product);
    }
    
    // a method with no parameters and no return value
    public void sayHello() {
        System.out.println("Hello!");
    }
    
    // a method with parameters and no return value
    public void sayHelloTo(String name) {
        System.out.println("Hello, " + name + "!");
    }
    
    // a method with parameters and a return value
    public int calculateSum(int a, int b) {
        int sum = a + b;
        return sum;
    }
    
    // a static method
    public static int multiply(int a, int b) {
        int product = a * b;
        return product;
    }
}
