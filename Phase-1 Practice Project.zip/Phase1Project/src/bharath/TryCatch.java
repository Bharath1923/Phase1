package bharath;

public class TryCatch {
    public static void main(String[] args) {
        try {
            int numerator = 10;
            int denominator = 0;
            int result = numerator / denominator;
            System.out.println("Result: " + result);
        } catch (ArithmeticException ex) {
            System.out.println("An exception occurred: " + ex.getMessage());
        }
    }
}
