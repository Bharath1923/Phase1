package bharath;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;

public class FileCRUD {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the file path: ");
        String filePath = scanner.nextLine();

        File file = new File(filePath);

        try {
            if (file.createNewFile()) {
                System.out.println("File created successfully.");
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Enter the content to write to the file: ");
        String content = scanner.nextLine();

        try {
            Files.write(Paths.get(filePath), content.getBytes());
            System.out.println("File updated successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("File content: ");
        try {
            String fileContent = new String(Files.readAllBytes(Paths.get(filePath)));
            System.out.println(fileContent);
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Do you want to delete the file? (yes/no)");
        String deleteOption = scanner.nextLine();

        if (deleteOption.equalsIgnoreCase("yes")) {
            if (file.delete()) {
                System.out.println("File deleted successfully.");
            } else {
                System.out.println("Failed to delete the file.");
            }
        }

        scanner.close();
    }
}
