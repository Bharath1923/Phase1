package bharath;

public class SleepAndWait {
    public static void main(String[] args) {
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                synchronized (this) {
                    try {
                        System.out.println("Thread is sleeping for 2 seconds");
                        Thread.sleep(2000); // Sleeping for 2 seconds
                        System.out.println("Thread woke up");
                        System.out.println("Thread is waiting");
                        wait(); // Waiting indefinitely until notified
                        System.out.println("Thread has been notified and resumed");
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        };

        Thread thread = new Thread(runnable);
        thread.start();

        synchronized (runnable) {
            try {
                Thread.sleep(4000); // Sleeping for 4 seconds
                System.out.println("Main thread woke up");
                System.out.println("Main thread is notifying the sleeping thread");
                runnable.notify(); // Notifying the sleeping thread
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
