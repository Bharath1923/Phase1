package bharath;

class MyThread extends Thread implements Runnable {
    public void run() {
        // Code to be executed in the thread
        System.out.println("Thread is running");
    }
}

public class Runnableimplementation {
    public static void main(String[] args) {
        // Create an instance of the thread by extending the Thread class
        MyThread myThread = new MyThread();

        // Start the thread
        myThread.start();

        // Create an instance of the thread by implementing the Runnable interface
        Runnable myRunnable = new Runnable() {
            public void run() {
                // Code to be executed in the thread
                System.out.println("Runnable thread is running");
            }
        };

        // Create a thread with the runnable
        Thread myThread2 = new Thread(myRunnable);

        // Start the thread
        myThread2.start();
    }
}
