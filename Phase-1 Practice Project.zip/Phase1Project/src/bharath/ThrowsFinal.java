package bharath;

class MyCustomException extends Exception {
    public MyCustomException(String message) {
        super(message);
    }
}

public class ThrowsFinal {
    public static void main(String[] args) {
        try {
            // Throwing a custom exception
            throw new MyCustomException("This is a custom exception");
        } catch (MyCustomException ex) {
            System.out.println("Caught custom exception: " + ex.getMessage());
        } finally {
            System.out.println("Finally block is executed");
        }

        try {
            // Throwing an exception using throw keyword
            int[] array = new int[5];
            int value = array[10]; // This will throw an ArrayIndexOutOfBoundsException
        } catch (ArrayIndexOutOfBoundsException ex) {
            System.out.println("Caught exception: " + ex.getMessage());
        } finally {
            System.out.println("Finally block is executed");
        }

        try {
            // Method declaration with throws clause
            performDivision(10, 0);
        } catch (ArithmeticException ex) {
            System.out.println("Caught exception: " + ex.getMessage());
        }
    }

    // Method throwing an exception using throws clause
    public static void performDivision(int numerator, int denominator) throws ArithmeticException {
        if (denominator == 0) {
            throw new ArithmeticException("Division by zero");
        }
        int result = numerator / denominator;
        System.out.println("Result: " + result);
    }
}
