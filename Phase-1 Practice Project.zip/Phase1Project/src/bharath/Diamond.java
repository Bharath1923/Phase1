package bharath;

interface Animal {
    default void makeSound() {
        System.out.println("Default sound of an animal.");
    }
}

interface Dog extends Animal {
    default void makeSound() {
        System.out.println("Bark! Bark!");
    }
}

interface Cat extends Animal {
    default void makeSound() {
        System.out.println("Meow! Meow!");
    }
}

class AnimalSound implements Dog, Cat {
    @Override
    public void makeSound() {
        Dog.super.makeSound(); // Resolve the diamond problem by explicitly invoking Dog's implementation
    }
}

public class Diamond {
    public static void main(String[] args) {
        AnimalSound animalSound = new AnimalSound();
        animalSound.makeSound();
    }
}
