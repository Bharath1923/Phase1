package bharath;

public class ExceptionHandling {
    public static void main(String[] args) {
        try {
            // Code that may throw an exception
            int numerator = 10;
            int denominator = 0;
            int result = numerator / denominator;
            System.out.println("Result: " + result);
        } catch (ArithmeticException ex) {
            // Handling the exception
            System.out.println("An exception occurred: " + ex.getMessage());
        } finally {
            // Code that always executes, regardless of whether an exception is thrown or caught
            System.out.println("Finally block is executed");
        }

        // Other code that continues to execute after exception handling
        System.out.println("Program continues...");
    }
}
