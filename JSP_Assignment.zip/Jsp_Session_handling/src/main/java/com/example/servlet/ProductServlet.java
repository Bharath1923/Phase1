package com.example.servlet;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import com.example.model.Product;

public class ProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve form data from request parameters
        String name = request.getParameter("name");
        double price = Double.parseDouble(request.getParameter("price"));
        String description = request.getParameter("description");

        // Create a new Product object with the captured data
        Product product = new Product(name, price, description);

        // Store the Product object in the session
        HttpSession session = request.getSession();
        session.setAttribute("product", product);

        // Redirect the user to the product details page
        response.sendRedirect("productDetails.jsp");
    }
}
