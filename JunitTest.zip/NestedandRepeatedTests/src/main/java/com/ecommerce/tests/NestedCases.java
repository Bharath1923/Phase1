package com.ecommerce.tests;

public class NestedCases
{
    public int add(int a, int b) {
        return a + b;
    }
}
